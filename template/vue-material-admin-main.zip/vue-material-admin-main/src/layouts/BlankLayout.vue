<!-- // ===============================|| Blank Layout ||=============================== // -->
<template>
  <VApp>
    <RouterView />
  </VApp>
</template>
<script setup lang="ts">
import { RouterView } from 'vue-router';
</script>
