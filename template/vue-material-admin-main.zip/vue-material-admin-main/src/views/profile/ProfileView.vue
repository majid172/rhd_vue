<template>
  <section>
    <VRow>
      <VCol cols="12">
        <VCard> </VCard>
      </VCol>
    </VRow>
  </section>
</template>
