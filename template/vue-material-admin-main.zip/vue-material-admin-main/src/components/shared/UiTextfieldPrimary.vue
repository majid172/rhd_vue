<script setup lang="ts">
// const props = defineProps({
//   title: String,
// });
</script>

<template>
  <v-text-field color="primary"><slot /></v-text-field>
</template>
